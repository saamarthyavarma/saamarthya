package Exception;

public class ExceptionClass extends Exception{

String message;
	
	public ExceptionClass(String msg)
	{
		message=msg;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}
}
