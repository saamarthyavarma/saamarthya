package Testing;

import static org.junit.Assert.*;

import org.junit.Test;

import Service.CustomerService;
public class TestClass {
	CustomerService obj=new CustomerService();
	@Test 
	public void testName()
	{
		boolean flag=obj.validateName("roh");
		assertEquals(false, flag);
		
	}
	
	@Test
	public void testNumber()
	{
		boolean flag=obj.validateNumber("12345");
		assertEquals(false, flag);
	}
	@Test
	public void testNumber2()
	{
		boolean flag=obj.validateNumber("1234567890");
		assertEquals(true, flag);
	}
	
	@Test
	public void testValidateSecondChoice()
	{
		boolean flag=obj.validateSecondChoice(2);
		assertEquals(true, flag);
	}

}
