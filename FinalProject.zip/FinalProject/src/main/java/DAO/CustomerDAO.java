package DAO;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import Bean.CustomerBean;

public class CustomerDAO implements ICustomerDAO{
	
Map<Long, CustomerBean> hash=new TreeMap<Long, CustomerBean>();


@Override
public void create(long id, CustomerBean objBean) {
	hash.put(id, objBean);
	System.out.println(hash.get(id));
}

@Override
public boolean validateID(long id) {
	if(hash.containsKey(id))
		return true;
	else 
	{	System.out.println("Invalid ID. Please enter a valid ID");
		return false;
	}
	
}

@Override
public boolean validateAcc(long id, String pass) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	if(obj.getPassword().matches(pass))
		return true;
	else
	return false;
}

@Override
public void showBalance(long id) {
	System.out.println(hash.get(id));
}

@Override
public void withdraw(long id, double amt) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	obj.setBalance(obj.getBalance()- amt);
}

public void deposit(long id, double amt) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	obj.setBalance(obj.getBalance()+ amt);

}

@Override
public void transfer(long id, long id2, double amt) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	CustomerBean obj2=(CustomerBean) hash.get(id2);
	obj.setBalance(obj.getBalance()- amt);
	hash.put(id, obj);
	obj2.setBalance(obj2.getBalance()+ amt);
	hash.put(id2, obj2);
	
}
@Override
public double getBalance(long id) {
	double bal;
	CustomerBean obj=(CustomerBean) hash.get(id);
	bal=obj.getBalance();
	System.out.println("Balance is-"+bal +"Inside DAO");
	return bal;
}
}
