package DAO;

import java.util.HashMap;
import java.util.TreeMap;

import Bean.CustomerBean;

public class CustomerDAO implements ICustomerDAO{
	
TreeMap<Long, CustomerBean> hash=new TreeMap<Long, CustomerBean>();
public void print()
{	System.out.println(hash);
	}
@Override
public void create(long id, CustomerBean objBean) {
	objBean.setBalance(0);
	hash.put(id, objBean);
	System.out.println(hash);
}

@Override
public boolean validateID(long id) {
	System.out.println(hash);
	if(hash.containsKey(id))
		return true;
	else 
	{	System.out.println("Invalid ID. Please enter a valid ID");
		return false;
	}
}

@Override
public boolean validateAcc(long id, String pass) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	if(obj.getPassword().matches(pass))
		return true;
	else
	return false;
}

@Override
public void showBalance(long id) {
	System.out.println(hash.get(id));
}

@Override
public void withdraw(long id, double amt) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	obj.setBalance(obj.getBalance()- amt);
}

public void deposit(long id, double amt) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	obj.setBalance(obj.getBalance()+ amt);

}

@Override
public void transfer(long id, long id2, double amt) {
	CustomerBean obj=(CustomerBean) hash.get(id);
	CustomerBean obj2=(CustomerBean) hash.get(id2);
	obj.setBalance(obj.getBalance()- amt);
	obj2.setBalance(obj2.getBalance()+ amt);

	
}
}
