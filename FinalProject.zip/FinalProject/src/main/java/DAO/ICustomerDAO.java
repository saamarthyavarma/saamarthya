package DAO;

import Bean.CustomerBean;

public interface ICustomerDAO {

	void create(long id, CustomerBean objBean);

	boolean validateID(long id);

	boolean validateAcc(long id, String pass);

	void showBalance(long id);

	void withdraw(long id, double amt);

	void transfer(long id, long id2, double amt);

}
