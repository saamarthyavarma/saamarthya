package Service;

public interface ICustomerService {

	boolean validateFirstChoice(int ch);

	boolean validateName(String fName);

	boolean validateNumber(String phNo);

	long generateID();

	boolean validateSecondChoice(int ch);

	boolean validateBalance(long id, double amt);

}
