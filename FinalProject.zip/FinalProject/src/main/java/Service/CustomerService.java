package Service;

public class CustomerService implements ICustomerService{
	final String namePattern="[A-Z]{1}[a-z]{1,}";
	final String phonePattern="[1-9]{1}[0-9]{9}";
	
	@Override
	public boolean validateFirstChoice(int ch) {
		if (ch==1 || ch==2 || ch==3)
			return true;
		else {
				System.out.println("Enter a valid choice.");
				return false;
			}
		}
	
	@Override
	public boolean validateName(String fName) {
		boolean flag=fName.matches(namePattern);
		if(flag==true)
		return true;
		else
			{	
				System.out.println("Please enter only alphabets with first alphabet as capital");
				return false;
			}
	}

	@Override
	public boolean validateNumber(String phNo) {
		if(phNo.matches(phonePattern))
			return true;
		else
		{
			System.out.println("Please enter a valid 10 digit number.");
			return false;
		}
	}
	@Override
	public long generateID() {
		double x;
		long y;
		x=Math.random()*1000000000;
		y=(long)x;
		return y;
	}

	@Override
	public boolean validateSecondChoice(int ch) {
		if(ch>=1 || ch<=6)
			return true;
		else 
		{	System.out.println("Please enter a valid choice");
			return false;
		}
		}

}
